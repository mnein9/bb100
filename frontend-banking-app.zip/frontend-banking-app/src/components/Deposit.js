import React, { useState } from 'react';
import axios from 'axios';

function Deposit() {
  const [amount, setAmount] = useState('');
  const [message, setMessage] = useState('');
  const [balance, setBalance] = useState('');

  const handleDeposit = async (event) => {
    event.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post('http://localhost:5001/api/users/deposit', { amount: parseFloat(amount) }, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setBalance(response.data.balance);
      setMessage('Deposit successful');
    } catch (error) {
      setMessage(error.response.data.message);
    }
  };

  return (
    <div>
      <h2>Deposit</h2>
      <form onSubmit={handleDeposit}>
        <input type="number" placeholder="Amount" value={amount} onChange={(e) => setAmount(e.target.value)} required />
        <button type="submit">Deposit</button>
      </form>
      {message && <p>{message}</p>}
      {balance && <p>New Balance: ${balance}</p>}
    </div>
  );
}

export default Deposit;
