const express = require('express');
const { createAccount, login, getProfile, deposit, withdraw } = require('../controllers/userController');
const auth = require('../middleware/auth');
const router = express.Router();

router.post('/create-account', createAccount);
router.post('/login', login);
router.get('/profile', auth, getProfile);
router.post('/deposit', auth, deposit);
router.post('/withdraw', auth, withdraw);

module.exports = router;
