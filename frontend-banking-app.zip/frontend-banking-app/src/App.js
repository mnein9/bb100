import React, { useState } from 'react';
import axios from 'axios';

function CreateAccount() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleCreateAccount = async (event) => {
    event.preventDefault();
    try {
      const response = await axios.post('http://localhost:5001/api/users/create-account', {
        name,
        email,
        password,
      });
      if (response.data) {
        setMessage(response.data.message);
      } else {
        setMessage('Account creation failed.');
      }
    } catch (error) {
      if (error.response && error.response.data && error.response.data.message) {
        setMessage(error.response.data.message);
      } else {
        setMessage('An error occurred. Please try again.');
      }
    }
  };

  return (
    <div>
      <h2>Create Account</h2>
      <form onSubmit={handleCreateAccount}>
        <input type="text" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} required />
        <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        <button type="submit">Create Account</button>
      </form>
      {message && <p>{message}</p>}
    </div>
  );
}

export default CreateAccount;
