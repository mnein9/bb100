import React, { useState } from 'react';
import axios from 'axios';

function Withdraw() {
  const [amount, setAmount] = useState('');
  const [message, setMessage] = useState('');
  const [balance, setBalance] = useState('');

  const handleWithdraw = async (event) => {
    event.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post('http://localhost:5001/api/users/withdraw', { amount: parseFloat(amount) }, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setBalance(response.data.balance);
      setMessage('Withdraw successful');
    } catch (error) {
      setMessage(error.response.data.message);
    }
  };

  return (
    <div>
      <h2>Withdraw</h2>
      <form onSubmit={handleWithdraw}>
        <input type="number" placeholder="Amount" value={amount} onChange={(e) => setAmount(e.target.value)} required />
        <button type="submit">Withdraw</button>
      </form>
      {message && <p>{message}</p>}
      {balance && <p>New Balance: ${balance}</p>}
    </div>
  );
}

export default Withdraw;
